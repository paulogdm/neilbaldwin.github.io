----------------------------------------
NTRQ : NES Music Tracker by Neil Baldwin
----------------------------------------

Please read/consult the manual - I spent a lot of time writing it!

For support/help you should visit the NTRQ Forum (http://ntrq.net/forum/index.php) first.

Any other questions, email me.

Neil
info@ntrq.net
http://ntrq.net

----------------------------------------
Files
----------------------------------------

Files you should have received:

"ntrq_NTSC.nes" - NTRQ ROM image (NTSC)
"ntrq_PAL.nes" - NTRQ ROM image (PAL)
"dmc2ntrq.c" - source code for DCM2NTRQ
"dcm2ntrq" - unix/Mac binary for DCM2NTRQ
"dcm2ntrq.exe" - windows binary for DCM2NTRQ
"ntrq2nsf.c" - source code for NTRQ2NSF
"ntrqnsf" - unix/Mac binary of NTRQ2NSF
"ntrq2nsf.exe" - windows (command line) binary of NTRQ2NSF
"NTRQNSF.BIN" - binary file needed by NTRQ2NSF
"Using The Command-line Tools.txt" - manual/usage instructions for NTRQ2NSF and DCM2NTRQ tools
"NTRQ Manual.pdf" - NTRQ manual in PDF format
"version.txt" - version information (bug fixes and changes)
"readme.txt" - this file
"ntrq-blank.sav" - 8KB .sav file (battery/WRAM), "formatted" for NTRQ
"ntrq-example.sav" - .sav file containing small example "song"
"license.txt" - license terms under which NTRQ is released

----------------------------------------
Known Issues as of V1.4 June 1 2010
----------------------------------------

- PAL version does not adjust speed to compensate for 50/60hz difference
- combination of hardware pitch sweep & auto echo doesn't work properly
- Sometimes notes get stuck on in Live Play mode
- Sometimes combination of hard & soft pitch sweep produces wrong note
- very slow/fast pitch slides are not very slow/fast (needs more work)
- couple of graphical glitches (especially on logo screen)
- no source code yet
- no stand-alone player
- external sync is still in development so doesn't work properly (at all)
