PR8 NES Drum Synth by Neil Baldwin (C) 2010
-------------------------------------------

Contact: neil@ntrq.net

What's in the package?

PR8.NES     - the NES ROM image
DCM2PR8.C   - source for ROM patcher
DCM2PR8     - Mac/Unix executable of ROM patcher
DCM2PR8.EXE - Windows executable of ROM patcher
pr8_dcm.txt - text file for patcher to 'restore' original samples
pr8_ex.sav  - .sav file containing some example Patterns and Drums
+ DPCM      - folder of DCM drum samples
+ Manual    - folder containing manual (index.html)
+ Powerpak  - folder containing mapper update required for Powerpak
              and blank 32kb .save file (if required)

readme.txt  - this file

Release History
---------------

V0.99b - October 31st 2011
Fixed a bug which prevented you from editing a Song longer than sixteen (10) steps

V0.99a - February 16th 2011
+ Added a check to make sure the emulator you are using can support
32KB save files. You'll get an error screen if 32K save files are
not supported

V0.99 - February 12th 2011
+ Initial release

Notes
-----

If you want to try out the example .sav file you'll need to rename it to
'pr8.sav' and copy it to where your emulator looks for .sav files. If you
are using PowerPak you can just copy it to your Compact Flash card and
then point PowerPak at it when loading PR8 by using the 'Load Battry File'
feature.

PowerPak
--------

You need a blank 32kb .save file to run PR8 on PowerPak. Copy the file
'32KB.sav' to the 'SAVES' folder on your Compact Flash card then rename
it to 'PR8.SAV'


Known Issues
------------

- using Retrigger can, in certain conditions, cause notes to sound 
  continuosly when changing Patterns.

- it's sometimes possible to set a Pitch value (note + octave) outside 
  of the 'legal' range. You'll see 'corrupt' display in the Note parameter
  of a Trigger. Please get in touch if you have this happen.

- not all Drum Patch parameters work properly when using Tie Notes

Planned Updates
---------------

+ External Sync
+ Better 'transport' controls for Song mode


