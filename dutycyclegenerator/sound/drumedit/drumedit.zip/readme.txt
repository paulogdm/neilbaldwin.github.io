June 12th 2009 - V0.1 Released
June 18th 2998 - Bug fix in 'drum2nij.c'
